(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_caf7a1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_caf7a1._.js",
  "chunks": [
    "static/chunks/src_app_page_tsx_8b213b._.js"
  ],
  "source": "dynamic"
});
